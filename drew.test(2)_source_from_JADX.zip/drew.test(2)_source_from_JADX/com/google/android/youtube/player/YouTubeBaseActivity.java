package com.google.android.youtube.player;

import android.app.Activity;
import android.os.Bundle;
import com.google.android.youtube.player.YouTubePlayer.OnInitializedListener;
import com.google.android.youtube.player.YouTubePlayerView.C0180b;

public class YouTubeBaseActivity extends Activity {
    private C0272a f4a;
    private YouTubePlayerView f5b;
    private int f6c;
    private Bundle f7d;

    /* renamed from: com.google.android.youtube.player.YouTubeBaseActivity.a */
    private final class C0272a implements C0180b {
        final /* synthetic */ YouTubeBaseActivity f54a;

        private C0272a(YouTubeBaseActivity youTubeBaseActivity) {
            this.f54a = youTubeBaseActivity;
        }

        public final void m140a(YouTubePlayerView youTubePlayerView) {
            if (!(this.f54a.f5b == null || this.f54a.f5b == youTubePlayerView)) {
                this.f54a.f5b.m172c(true);
            }
            this.f54a.f5b = youTubePlayerView;
            if (this.f54a.f6c > 0) {
                youTubePlayerView.m166a();
            }
            if (this.f54a.f6c >= 2) {
                youTubePlayerView.m169b();
            }
        }

        public final void m141a(YouTubePlayerView youTubePlayerView, String str, OnInitializedListener onInitializedListener) {
            youTubePlayerView.m167a(this.f54a, youTubePlayerView, str, onInitializedListener, this.f54a.f7d);
            this.f54a.f7d = null;
        }
    }

    final C0180b m15a() {
        return this.f4a;
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f4a = new C0272a();
        this.f7d = bundle != null ? bundle.getBundle("YouTubeBaseActivity.KEY_PLAYER_VIEW_STATE") : null;
    }

    protected void onDestroy() {
        if (this.f5b != null) {
            this.f5b.m170b(isFinishing());
        }
        super.onDestroy();
    }

    protected void onPause() {
        this.f6c = 1;
        if (this.f5b != null) {
            this.f5b.m171c();
        }
        super.onPause();
    }

    protected void onResume() {
        super.onResume();
        this.f6c = 2;
        if (this.f5b != null) {
            this.f5b.m169b();
        }
    }

    protected void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putBundle("YouTubeBaseActivity.KEY_PLAYER_VIEW_STATE", this.f5b != null ? this.f5b.m174e() : this.f7d);
    }

    protected void onStart() {
        super.onStart();
        this.f6c = 1;
        if (this.f5b != null) {
            this.f5b.m166a();
        }
    }

    protected void onStop() {
        this.f6c = 0;
        if (this.f5b != null) {
            this.f5b.m173d();
        }
        super.onStop();
    }
}
