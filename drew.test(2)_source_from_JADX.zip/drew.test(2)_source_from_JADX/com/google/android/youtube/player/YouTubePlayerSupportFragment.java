package com.google.android.youtube.player;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.youtube.player.YouTubePlayer.OnInitializedListener;
import com.google.android.youtube.player.YouTubePlayer.Provider;
import com.google.android.youtube.player.YouTubePlayerView.C0180b;
import com.google.android.youtube.player.internal.ab;

public class YouTubePlayerSupportFragment extends Fragment implements Provider {
    private final C0274a f63a;
    private Bundle f64b;
    private YouTubePlayerView f65c;
    private String f66d;
    private OnInitializedListener f67e;
    private boolean f68f;

    /* renamed from: com.google.android.youtube.player.YouTubePlayerSupportFragment.a */
    private final class C0274a implements C0180b {
        final /* synthetic */ YouTubePlayerSupportFragment f62a;

        private C0274a(YouTubePlayerSupportFragment youTubePlayerSupportFragment) {
            this.f62a = youTubePlayerSupportFragment;
        }

        public final void m146a(YouTubePlayerView youTubePlayerView) {
        }

        public final void m147a(YouTubePlayerView youTubePlayerView, String str, OnInitializedListener onInitializedListener) {
            this.f62a.initialize(str, this.f62a.f67e);
        }
    }

    public YouTubePlayerSupportFragment() {
        this.f63a = new C0274a();
    }

    private void m149a() {
        if (this.f65c != null && this.f67e != null) {
            this.f65c.m168a(this.f68f);
            this.f65c.m167a(getActivity(), this, this.f66d, this.f67e, this.f64b);
            this.f64b = null;
            this.f67e = null;
        }
    }

    public static YouTubePlayerSupportFragment newInstance() {
        return new YouTubePlayerSupportFragment();
    }

    public void initialize(String str, OnInitializedListener onInitializedListener) {
        this.f66d = ab.m36a(str, (Object) "Developer key cannot be null or empty");
        this.f67e = onInitializedListener;
        m149a();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f64b = bundle != null ? bundle.getBundle("YouTubePlayerSupportFragment.KEY_PLAYER_VIEW_STATE") : null;
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f65c = new YouTubePlayerView(getActivity(), null, 0, this.f63a);
        m149a();
        return this.f65c;
    }

    public void onDestroy() {
        if (this.f65c != null) {
            Activity activity = getActivity();
            YouTubePlayerView youTubePlayerView = this.f65c;
            boolean z = activity == null || activity.isFinishing();
            youTubePlayerView.m170b(z);
        }
        super.onDestroy();
    }

    public void onDestroyView() {
        this.f65c.m172c(getActivity().isFinishing());
        this.f65c = null;
        super.onDestroyView();
    }

    public void onPause() {
        this.f65c.m171c();
        super.onPause();
    }

    public void onResume() {
        super.onResume();
        this.f65c.m169b();
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putBundle("YouTubePlayerSupportFragment.KEY_PLAYER_VIEW_STATE", this.f65c != null ? this.f65c.m174e() : this.f64b);
    }

    public void onStart() {
        super.onStart();
        this.f65c.m166a();
    }

    public void onStop() {
        this.f65c.m173d();
        super.onStop();
    }
}
