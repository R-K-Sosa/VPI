package com.google.android.youtube.player;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.widget.ListPopupWindow;
import com.google.android.youtube.player.internal.C0191m;
import com.google.android.youtube.player.internal.C0207y;
import com.google.android.youtube.player.internal.C0208z;
import com.google.android.youtube.player.internal.ab;

public enum YouTubeInitializationResult {
    SUCCESS,
    INTERNAL_ERROR,
    UNKNOWN_ERROR,
    SERVICE_MISSING,
    SERVICE_VERSION_UPDATE_REQUIRED,
    SERVICE_DISABLED,
    SERVICE_INVALID,
    ERROR_CONNECTING_TO_SERVICE,
    CLIENT_LIBRARY_UPDATE_REQUIRED,
    NETWORK_ERROR,
    DEVELOPER_KEY_INVALID,
    INVALID_APPLICATION_SIGNATURE;

    /* renamed from: com.google.android.youtube.player.YouTubeInitializationResult.1 */
    static /* synthetic */ class C01771 {
        static final /* synthetic */ int[] f8a;

        static {
            f8a = new int[YouTubeInitializationResult.values().length];
            try {
                f8a[YouTubeInitializationResult.SERVICE_MISSING.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                f8a[YouTubeInitializationResult.SERVICE_DISABLED.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                f8a[YouTubeInitializationResult.SERVICE_VERSION_UPDATE_REQUIRED.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
        }
    }

    /* renamed from: com.google.android.youtube.player.YouTubeInitializationResult.a */
    private static final class C0178a implements OnClickListener {
        private final Activity f9a;
        private final Intent f10b;
        private final int f11c;

        public C0178a(Activity activity, Intent intent, int i) {
            this.f9a = (Activity) ab.m34a((Object) activity);
            this.f10b = (Intent) ab.m34a((Object) intent);
            this.f11c = ((Integer) ab.m34a(Integer.valueOf(i))).intValue();
        }

        public final void onClick(DialogInterface dialogInterface, int i) {
            try {
                this.f9a.startActivityForResult(this.f10b, this.f11c);
                dialogInterface.dismiss();
            } catch (Throwable e) {
                C0207y.m125a("Can't perform resolution for YouTubeInitalizationError", e);
            }
        }
    }

    public final Dialog getErrorDialog(Activity activity, int i) {
        return getErrorDialog(activity, i, null);
    }

    public final Dialog getErrorDialog(Activity activity, int i, OnCancelListener onCancelListener) {
        Intent b;
        Builder builder = new Builder(activity);
        if (onCancelListener != null) {
            builder.setOnCancelListener(onCancelListener);
        }
        switch (C01771.f8a[ordinal()]) {
            case ListPopupWindow.POSITION_PROMPT_BELOW /*1*/:
            case DrawerLayout.LOCK_MODE_UNDEFINED /*3*/:
                b = C0208z.m133b(C0208z.m129a((Context) activity));
                break;
            case ListPopupWindow.INPUT_METHOD_NOT_NEEDED /*2*/:
                b = C0208z.m127a(C0208z.m129a((Context) activity));
                break;
            default:
                b = null;
                break;
        }
        OnClickListener c0178a = new C0178a(activity, b, i);
        C0191m c0191m = new C0191m(activity);
        switch (C01771.f8a[ordinal()]) {
            case ListPopupWindow.POSITION_PROMPT_BELOW /*1*/:
                return builder.setTitle(c0191m.f21b).setMessage(c0191m.f22c).setPositiveButton(c0191m.f23d, c0178a).create();
            case ListPopupWindow.INPUT_METHOD_NOT_NEEDED /*2*/:
                return builder.setTitle(c0191m.f24e).setMessage(c0191m.f25f).setPositiveButton(c0191m.f26g, c0178a).create();
            case DrawerLayout.LOCK_MODE_UNDEFINED /*3*/:
                return builder.setTitle(c0191m.f27h).setMessage(c0191m.f28i).setPositiveButton(c0191m.f29j, c0178a).create();
            default:
                String str = "Unexpected errorReason: ";
                String valueOf = String.valueOf(name());
                throw new IllegalArgumentException(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
        }
    }

    public final boolean isUserRecoverableError() {
        switch (C01771.f8a[ordinal()]) {
            case ListPopupWindow.POSITION_PROMPT_BELOW /*1*/:
            case ListPopupWindow.INPUT_METHOD_NOT_NEEDED /*2*/:
            case DrawerLayout.LOCK_MODE_UNDEFINED /*3*/:
                return true;
            default:
                return false;
        }
    }
}
