package com.google.android.youtube.player;

import android.app.Activity;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.youtube.player.YouTubePlayer.OnInitializedListener;
import com.google.android.youtube.player.YouTubePlayer.Provider;
import com.google.android.youtube.player.YouTubePlayerView.C0180b;
import com.google.android.youtube.player.internal.ab;

public class YouTubePlayerFragment extends Fragment implements Provider {
    private final C0273a f56a;
    private Bundle f57b;
    private YouTubePlayerView f58c;
    private String f59d;
    private OnInitializedListener f60e;
    private boolean f61f;

    /* renamed from: com.google.android.youtube.player.YouTubePlayerFragment.a */
    private final class C0273a implements C0180b {
        final /* synthetic */ YouTubePlayerFragment f55a;

        private C0273a(YouTubePlayerFragment youTubePlayerFragment) {
            this.f55a = youTubePlayerFragment;
        }

        public final void m142a(YouTubePlayerView youTubePlayerView) {
        }

        public final void m143a(YouTubePlayerView youTubePlayerView, String str, OnInitializedListener onInitializedListener) {
            this.f55a.initialize(str, this.f55a.f60e);
        }
    }

    public YouTubePlayerFragment() {
        this.f56a = new C0273a();
    }

    private void m145a() {
        if (this.f58c != null && this.f60e != null) {
            this.f58c.m168a(this.f61f);
            this.f58c.m167a(getActivity(), this, this.f59d, this.f60e, this.f57b);
            this.f57b = null;
            this.f60e = null;
        }
    }

    public static YouTubePlayerFragment newInstance() {
        return new YouTubePlayerFragment();
    }

    public void initialize(String str, OnInitializedListener onInitializedListener) {
        this.f59d = ab.m36a(str, (Object) "Developer key cannot be null or empty");
        this.f60e = onInitializedListener;
        m145a();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f57b = bundle != null ? bundle.getBundle("YouTubePlayerFragment.KEY_PLAYER_VIEW_STATE") : null;
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f58c = new YouTubePlayerView(getActivity(), null, 0, this.f56a);
        m145a();
        return this.f58c;
    }

    public void onDestroy() {
        if (this.f58c != null) {
            Activity activity = getActivity();
            YouTubePlayerView youTubePlayerView = this.f58c;
            boolean z = activity == null || activity.isFinishing();
            youTubePlayerView.m170b(z);
        }
        super.onDestroy();
    }

    public void onDestroyView() {
        this.f58c.m172c(getActivity().isFinishing());
        this.f58c = null;
        super.onDestroyView();
    }

    public void onPause() {
        this.f58c.m171c();
        super.onPause();
    }

    public void onResume() {
        super.onResume();
        this.f58c.m169b();
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putBundle("YouTubePlayerFragment.KEY_PLAYER_VIEW_STATE", this.f58c != null ? this.f58c.m174e() : this.f57b);
    }

    public void onStart() {
        super.onStart();
        this.f58c.m166a();
    }

    public void onStop() {
        this.f58c.m173d();
        super.onStop();
    }
}
