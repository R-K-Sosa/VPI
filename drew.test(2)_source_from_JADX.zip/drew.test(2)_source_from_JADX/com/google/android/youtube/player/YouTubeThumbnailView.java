package com.google.android.youtube.player;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageView;
import com.google.android.youtube.player.internal.C0202t.C0200a;
import com.google.android.youtube.player.internal.C0202t.C0201b;
import com.google.android.youtube.player.internal.C0278a;
import com.google.android.youtube.player.internal.C0279b;
import com.google.android.youtube.player.internal.aa;
import com.google.android.youtube.player.internal.ab;

public final class YouTubeThumbnailView extends ImageView {
    private C0279b f17a;
    private C0278a f18b;

    public interface OnInitializedListener {
        void onInitializationFailure(YouTubeThumbnailView youTubeThumbnailView, YouTubeInitializationResult youTubeInitializationResult);

        void onInitializationSuccess(YouTubeThumbnailView youTubeThumbnailView, YouTubeThumbnailLoader youTubeThumbnailLoader);
    }

    /* renamed from: com.google.android.youtube.player.YouTubeThumbnailView.a */
    private static final class C0277a implements C0200a, C0201b {
        private YouTubeThumbnailView f84a;
        private OnInitializedListener f85b;

        public C0277a(YouTubeThumbnailView youTubeThumbnailView, OnInitializedListener onInitializedListener) {
            this.f84a = (YouTubeThumbnailView) ab.m35a((Object) youTubeThumbnailView, (Object) "thumbnailView cannot be null");
            this.f85b = (OnInitializedListener) ab.m35a((Object) onInitializedListener, (Object) "onInitializedlistener cannot be null");
        }

        private void m175c() {
            if (this.f84a != null) {
                this.f84a.f17a = null;
                this.f84a = null;
                this.f85b = null;
            }
        }

        public final void m176a() {
            if (this.f84a != null && this.f84a.f17a != null) {
                this.f84a.f18b = aa.m29a().m31a(this.f84a.f17a, this.f84a);
                this.f85b.onInitializationSuccess(this.f84a, this.f84a.f18b);
                m175c();
            }
        }

        public final void m177a(YouTubeInitializationResult youTubeInitializationResult) {
            this.f85b.onInitializationFailure(this.f84a, youTubeInitializationResult);
            m175c();
        }

        public final void m178b() {
            m175c();
        }
    }

    public YouTubeThumbnailView(Context context) {
        this(context, null);
    }

    public YouTubeThumbnailView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public YouTubeThumbnailView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    protected final void finalize() throws Throwable {
        if (this.f18b != null) {
            this.f18b.m184b();
            this.f18b = null;
        }
        super.finalize();
    }

    public final void initialize(String str, OnInitializedListener onInitializedListener) {
        Object c0277a = new C0277a(this, onInitializedListener);
        this.f17a = aa.m29a().m32a(getContext(), str, c0277a, c0277a);
        this.f17a.m119e();
    }
}
