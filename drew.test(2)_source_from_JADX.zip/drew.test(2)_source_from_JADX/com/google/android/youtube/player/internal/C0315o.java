package com.google.android.youtube.player.internal;

import android.content.Context;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.youtube.player.internal.C0190l.C0299a;
import com.google.android.youtube.player.internal.C0202t.C0200a;
import com.google.android.youtube.player.internal.C0202t.C0201b;
import com.google.android.youtube.player.internal.C0301r.C0318d;

/* renamed from: com.google.android.youtube.player.internal.o */
public final class C0315o extends C0301r<C0190l> implements C0279b {
    private final String f117b;
    private final String f118c;
    private final String f119d;
    private boolean f120e;

    public C0315o(Context context, String str, String str2, String str3, C0200a c0200a, C0201b c0201b) {
        super(context, c0200a, c0201b);
        this.f117b = (String) ab.m34a((Object) str);
        this.f118c = ab.m36a(str2, (Object) "callingPackage cannot be null or empty");
        this.f119d = ab.m36a(str3, (Object) "callingAppVersion cannot be null or empty");
    }

    private final void m313k() {
        m294i();
        if (this.f120e) {
            throw new IllegalStateException("Connection client has been released");
        }
    }

    public final IBinder m314a() {
        m313k();
        try {
            return ((C0190l) m295j()).m106a();
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    protected final /* synthetic */ IInterface m315a(IBinder iBinder) {
        return C0299a.m272a(iBinder);
    }

    public final C0189k m316a(C0188j c0188j) {
        m313k();
        try {
            return ((C0190l) m295j()).m107a(c0188j);
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    protected final void m317a(C0187i c0187i, C0318d c0318d) throws RemoteException {
        c0187i.m97a(c0318d, 1202, this.f118c, this.f119d, this.f117b, null);
    }

    public final void m318a(boolean z) {
        if (m291f()) {
            try {
                ((C0190l) m295j()).m108a(z);
            } catch (RemoteException e) {
            }
            this.f120e = true;
        }
    }

    protected final String m319b() {
        return "com.google.android.youtube.player.internal.IYouTubeService";
    }

    protected final String m320c() {
        return "com.google.android.youtube.api.service.START";
    }

    public final void m321d() {
        if (!this.f120e) {
            m318a(true);
        }
        super.m289d();
    }
}
