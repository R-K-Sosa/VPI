package com.google.android.youtube.player.internal;

import android.content.res.Configuration;
import android.os.Bundle;
import android.os.RemoteException;
import android.view.KeyEvent;
import android.view.View;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayer.ErrorReason;
import com.google.android.youtube.player.YouTubePlayer.OnFullscreenListener;
import com.google.android.youtube.player.YouTubePlayer.PlaybackEventListener;
import com.google.android.youtube.player.YouTubePlayer.PlayerStateChangeListener;
import com.google.android.youtube.player.YouTubePlayer.PlayerStyle;
import com.google.android.youtube.player.YouTubePlayer.PlaylistEventListener;
import com.google.android.youtube.player.internal.C0183e.C0285a;
import com.google.android.youtube.player.internal.C0184f.C0287a;
import com.google.android.youtube.player.internal.C0185g.C0289a;
import com.google.android.youtube.player.internal.C0186h.C0291a;
import java.util.List;

/* renamed from: com.google.android.youtube.player.internal.s */
public final class C0302s implements YouTubePlayer {
    private C0279b f114a;
    private C0182d f115b;

    /* renamed from: com.google.android.youtube.player.internal.s.1 */
    class C03191 extends C0285a {
        final /* synthetic */ OnFullscreenListener f128a;
        final /* synthetic */ C0302s f129b;

        C03191(C0302s c0302s, OnFullscreenListener onFullscreenListener) {
            this.f129b = c0302s;
            this.f128a = onFullscreenListener;
        }

        public final void m337a(boolean z) {
            this.f128a.onFullscreen(z);
        }
    }

    /* renamed from: com.google.android.youtube.player.internal.s.2 */
    class C03202 extends C0291a {
        final /* synthetic */ PlaylistEventListener f130a;
        final /* synthetic */ C0302s f131b;

        C03202(C0302s c0302s, PlaylistEventListener playlistEventListener) {
            this.f131b = c0302s;
            this.f130a = playlistEventListener;
        }

        public final void m338a() {
            this.f130a.onPrevious();
        }

        public final void m339b() {
            this.f130a.onNext();
        }

        public final void m340c() {
            this.f130a.onPlaylistEnded();
        }
    }

    /* renamed from: com.google.android.youtube.player.internal.s.3 */
    class C03213 extends C0289a {
        final /* synthetic */ PlayerStateChangeListener f132a;
        final /* synthetic */ C0302s f133b;

        C03213(C0302s c0302s, PlayerStateChangeListener playerStateChangeListener) {
            this.f133b = c0302s;
            this.f132a = playerStateChangeListener;
        }

        public final void m341a() {
            this.f132a.onLoading();
        }

        public final void m342a(String str) {
            this.f132a.onLoaded(str);
        }

        public final void m343b() {
            this.f132a.onAdStarted();
        }

        public final void m344b(String str) {
            ErrorReason valueOf;
            try {
                valueOf = ErrorReason.valueOf(str);
            } catch (IllegalArgumentException e) {
                valueOf = ErrorReason.UNKNOWN;
            } catch (NullPointerException e2) {
                valueOf = ErrorReason.UNKNOWN;
            }
            this.f132a.onError(valueOf);
        }

        public final void m345c() {
            this.f132a.onVideoStarted();
        }

        public final void m346d() {
            this.f132a.onVideoEnded();
        }
    }

    /* renamed from: com.google.android.youtube.player.internal.s.4 */
    class C03224 extends C0287a {
        final /* synthetic */ PlaybackEventListener f134a;
        final /* synthetic */ C0302s f135b;

        C03224(C0302s c0302s, PlaybackEventListener playbackEventListener) {
            this.f135b = c0302s;
            this.f134a = playbackEventListener;
        }

        public final void m347a() {
            this.f134a.onPlaying();
        }

        public final void m348a(int i) {
            this.f134a.onSeekTo(i);
        }

        public final void m349a(boolean z) {
            this.f134a.onBuffering(z);
        }

        public final void m350b() {
            this.f134a.onPaused();
        }

        public final void m351c() {
            this.f134a.onStopped();
        }
    }

    public C0302s(C0279b c0279b, C0182d c0182d) {
        this.f114a = (C0279b) ab.m35a((Object) c0279b, (Object) "connectionClient cannot be null");
        this.f115b = (C0182d) ab.m35a((Object) c0182d, (Object) "embeddedPlayer cannot be null");
    }

    public final View m296a() {
        try {
            return (View) C0323v.m353a(this.f115b.m81s());
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final void m297a(Configuration configuration) {
        try {
            this.f115b.m41a(configuration);
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final void m298a(boolean z) {
        try {
            this.f115b.m50a(z);
            this.f114a.m197a(z);
            this.f114a.m118d();
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final boolean m299a(int i, KeyEvent keyEvent) {
        try {
            return this.f115b.m51a(i, keyEvent);
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final boolean m300a(Bundle bundle) {
        try {
            return this.f115b.m52a(bundle);
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final void addFullscreenControlFlag(int i) {
        try {
            this.f115b.m63d(i);
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final void m301b() {
        try {
            this.f115b.m75m();
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final void m302b(boolean z) {
        try {
            this.f115b.m66e(z);
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final boolean m303b(int i, KeyEvent keyEvent) {
        try {
            return this.f115b.m59b(i, keyEvent);
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final void m304c() {
        try {
            this.f115b.m76n();
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final void cuePlaylist(String str) {
        cuePlaylist(str, 0, 0);
    }

    public final void cuePlaylist(String str, int i, int i2) {
        try {
            this.f115b.m48a(str, i, i2);
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final void cueVideo(String str) {
        cueVideo(str, 0);
    }

    public final void cueVideo(String str, int i) {
        try {
            this.f115b.m47a(str, i);
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final void cueVideos(List<String> list) {
        cueVideos(list, 0, 0);
    }

    public final void cueVideos(List<String> list, int i, int i2) {
        try {
            this.f115b.m49a((List) list, i, i2);
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final void m305d() {
        try {
            this.f115b.m77o();
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final void m306e() {
        try {
            this.f115b.m78p();
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final void m307f() {
        try {
            this.f115b.m79q();
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final void m308g() {
        try {
            this.f115b.m74l();
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final int getCurrentTimeMillis() {
        try {
            return this.f115b.m70h();
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final int getDurationMillis() {
        try {
            return this.f115b.m71i();
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final int getFullscreenControlFlags() {
        try {
            return this.f115b.m72j();
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final Bundle m309h() {
        try {
            return this.f115b.m80r();
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final boolean hasNext() {
        try {
            return this.f115b.m65d();
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final boolean hasPrevious() {
        try {
            return this.f115b.m67e();
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final boolean isPlaying() {
        try {
            return this.f115b.m62c();
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final void loadPlaylist(String str) {
        loadPlaylist(str, 0, 0);
    }

    public final void loadPlaylist(String str, int i, int i2) {
        try {
            this.f115b.m56b(str, i, i2);
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final void loadVideo(String str) {
        loadVideo(str, 0);
    }

    public final void loadVideo(String str, int i) {
        try {
            this.f115b.m55b(str, i);
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final void loadVideos(List<String> list) {
        loadVideos(list, 0, 0);
    }

    public final void loadVideos(List<String> list, int i, int i2) {
        try {
            this.f115b.m57b((List) list, i, i2);
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final void next() {
        try {
            this.f115b.m68f();
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final void pause() {
        try {
            this.f115b.m53b();
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final void play() {
        try {
            this.f115b.m39a();
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final void previous() {
        try {
            this.f115b.m69g();
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final void release() {
        m298a(true);
    }

    public final void seekRelativeMillis(int i) {
        try {
            this.f115b.m54b(i);
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final void seekToMillis(int i) {
        try {
            this.f115b.m40a(i);
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final void setFullscreen(boolean z) {
        try {
            this.f115b.m58b(z);
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final void setFullscreenControlFlags(int i) {
        try {
            this.f115b.m60c(i);
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final void setManageAudioFocus(boolean z) {
        try {
            this.f115b.m64d(z);
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final void setOnFullscreenListener(OnFullscreenListener onFullscreenListener) {
        try {
            this.f115b.m42a(new C03191(this, onFullscreenListener));
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final void setPlaybackEventListener(PlaybackEventListener playbackEventListener) {
        try {
            this.f115b.m43a(new C03224(this, playbackEventListener));
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final void setPlayerStateChangeListener(PlayerStateChangeListener playerStateChangeListener) {
        try {
            this.f115b.m44a(new C03213(this, playerStateChangeListener));
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final void setPlayerStyle(PlayerStyle playerStyle) {
        try {
            this.f115b.m46a(playerStyle.name());
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final void setPlaylistEventListener(PlaylistEventListener playlistEventListener) {
        try {
            this.f115b.m45a(new C03202(this, playlistEventListener));
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }

    public final void setShowFullscreenButton(boolean z) {
        try {
            this.f115b.m61c(z);
        } catch (RemoteException e) {
            throw new C0195q(e);
        }
    }
}
