package com.google.android.youtube.player.internal;

import android.graphics.Bitmap;
import com.google.android.youtube.player.YouTubeThumbnailLoader;
import com.google.android.youtube.player.YouTubeThumbnailLoader.ErrorReason;
import com.google.android.youtube.player.YouTubeThumbnailLoader.OnThumbnailLoadedListener;
import com.google.android.youtube.player.YouTubeThumbnailView;
import java.lang.ref.WeakReference;
import java.util.NoSuchElementException;

/* renamed from: com.google.android.youtube.player.internal.a */
public abstract class C0278a implements YouTubeThumbnailLoader {
    private final WeakReference<YouTubeThumbnailView> f86a;
    private OnThumbnailLoadedListener f87b;
    private boolean f88c;
    private boolean f89d;

    public C0278a(YouTubeThumbnailView youTubeThumbnailView) {
        this.f86a = new WeakReference(ab.m34a((Object) youTubeThumbnailView));
    }

    private void m179i() {
        if (!m183a()) {
            throw new IllegalStateException("This YouTubeThumbnailLoader has been released");
        }
    }

    public final void m180a(Bitmap bitmap, String str) {
        YouTubeThumbnailView youTubeThumbnailView = (YouTubeThumbnailView) this.f86a.get();
        if (m183a() && youTubeThumbnailView != null) {
            youTubeThumbnailView.setImageBitmap(bitmap);
            if (this.f87b != null) {
                this.f87b.onThumbnailLoaded(youTubeThumbnailView, str);
            }
        }
    }

    public abstract void m181a(String str);

    public abstract void m182a(String str, int i);

    protected boolean m183a() {
        return !this.f89d;
    }

    public final void m184b() {
        if (m183a()) {
            C0207y.m126a("The finalize() method for a YouTubeThumbnailLoader has work to do. You should have called release().", new Object[0]);
            release();
        }
    }

    public final void m185b(String str) {
        YouTubeThumbnailView youTubeThumbnailView = (YouTubeThumbnailView) this.f86a.get();
        if (m183a() && this.f87b != null && youTubeThumbnailView != null) {
            ErrorReason valueOf;
            try {
                valueOf = ErrorReason.valueOf(str);
            } catch (IllegalArgumentException e) {
                valueOf = ErrorReason.UNKNOWN;
            } catch (NullPointerException e2) {
                valueOf = ErrorReason.UNKNOWN;
            }
            this.f87b.onThumbnailError(youTubeThumbnailView, valueOf);
        }
    }

    public abstract void m186c();

    public abstract void m187d();

    public abstract void m188e();

    public abstract boolean m189f();

    public final void first() {
        m179i();
        if (this.f88c) {
            m188e();
            return;
        }
        throw new IllegalStateException("Must call setPlaylist first");
    }

    public abstract boolean m190g();

    public abstract void m191h();

    public final boolean hasNext() {
        m179i();
        return m189f();
    }

    public final boolean hasPrevious() {
        m179i();
        return m190g();
    }

    public final void next() {
        m179i();
        if (!this.f88c) {
            throw new IllegalStateException("Must call setPlaylist first");
        } else if (m189f()) {
            m186c();
        } else {
            throw new NoSuchElementException("Called next at end of playlist");
        }
    }

    public final void previous() {
        m179i();
        if (!this.f88c) {
            throw new IllegalStateException("Must call setPlaylist first");
        } else if (m190g()) {
            m187d();
        } else {
            throw new NoSuchElementException("Called previous at start of playlist");
        }
    }

    public final void release() {
        if (m183a()) {
            this.f89d = true;
            this.f87b = null;
            m191h();
        }
    }

    public final void setOnThumbnailLoadedListener(OnThumbnailLoadedListener onThumbnailLoadedListener) {
        m179i();
        this.f87b = onThumbnailLoadedListener;
    }

    public final void setPlaylist(String str) {
        setPlaylist(str, 0);
    }

    public final void setPlaylist(String str, int i) {
        m179i();
        this.f88c = true;
        m182a(str, i);
    }

    public final void setVideo(String str) {
        m179i();
        this.f88c = false;
        m181a(str);
    }
}
