package com.google.android.youtube.player.internal;

import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import android.os.RemoteException;
import com.google.android.youtube.player.YouTubeThumbnailView;
import com.google.android.youtube.player.internal.C0188j.C0295a;

/* renamed from: com.google.android.youtube.player.internal.p */
public final class C0317p extends C0278a {
    private final Handler f122a;
    private C0279b f123b;
    private C0189k f124c;
    private boolean f125d;
    private boolean f126e;

    /* renamed from: com.google.android.youtube.player.internal.p.a */
    private final class C0316a extends C0295a {
        final /* synthetic */ C0317p f121a;

        /* renamed from: com.google.android.youtube.player.internal.p.a.1 */
        class C01931 implements Runnable {
            final /* synthetic */ boolean f32a;
            final /* synthetic */ boolean f33b;
            final /* synthetic */ Bitmap f34c;
            final /* synthetic */ String f35d;
            final /* synthetic */ C0316a f36e;

            C01931(C0316a c0316a, boolean z, boolean z2, Bitmap bitmap, String str) {
                this.f36e = c0316a;
                this.f32a = z;
                this.f33b = z2;
                this.f34c = bitmap;
                this.f35d = str;
            }

            public final void run() {
                this.f36e.f121a.f125d = this.f32a;
                this.f36e.f121a.f126e = this.f33b;
                this.f36e.f121a.m180a(this.f34c, this.f35d);
            }
        }

        /* renamed from: com.google.android.youtube.player.internal.p.a.2 */
        class C01942 implements Runnable {
            final /* synthetic */ boolean f37a;
            final /* synthetic */ boolean f38b;
            final /* synthetic */ String f39c;
            final /* synthetic */ C0316a f40d;

            C01942(C0316a c0316a, boolean z, boolean z2, String str) {
                this.f40d = c0316a;
                this.f37a = z;
                this.f38b = z2;
                this.f39c = str;
            }

            public final void run() {
                this.f40d.f121a.f125d = this.f37a;
                this.f40d.f121a.f126e = this.f38b;
                this.f40d.f121a.m185b(this.f39c);
            }
        }

        private C0316a(C0317p c0317p) {
            this.f121a = c0317p;
        }

        public final void m322a(Bitmap bitmap, String str, boolean z, boolean z2) {
            this.f121a.f122a.post(new C01931(this, z, z2, bitmap, str));
        }

        public final void m323a(String str, boolean z, boolean z2) {
            this.f121a.f122a.post(new C01942(this, z, z2, str));
        }
    }

    public C0317p(C0279b c0279b, YouTubeThumbnailView youTubeThumbnailView) {
        super(youTubeThumbnailView);
        this.f123b = (C0279b) ab.m35a((Object) c0279b, (Object) "connectionClient cannot be null");
        this.f124c = c0279b.m196a(new C0316a());
        this.f122a = new Handler(Looper.getMainLooper());
    }

    public final void m327a(String str) {
        try {
            this.f124c.m101a(str);
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    public final void m328a(String str, int i) {
        try {
            this.f124c.m102a(str, i);
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    protected final boolean m329a() {
        return super.m183a() && this.f124c != null;
    }

    public final void m330c() {
        try {
            this.f124c.m100a();
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    public final void m331d() {
        try {
            this.f124c.m103b();
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    public final void m332e() {
        try {
            this.f124c.m104c();
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    public final boolean m333f() {
        return this.f126e;
    }

    public final boolean m334g() {
        return this.f125d;
    }

    public final void m335h() {
        try {
            this.f124c.m105d();
        } catch (RemoteException e) {
        }
        this.f123b.m118d();
        this.f124c = null;
        this.f123b = null;
    }
}
