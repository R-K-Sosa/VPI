package com.google.android.youtube.player.internal;

import com.google.android.youtube.player.YouTubeInitializationResult;

/* renamed from: com.google.android.youtube.player.internal.t */
public interface C0202t {

    /* renamed from: com.google.android.youtube.player.internal.t.a */
    public interface C0200a {
        void m115a();

        void m116b();
    }

    /* renamed from: com.google.android.youtube.player.internal.t.b */
    public interface C0201b {
        void m117a(YouTubeInitializationResult youTubeInitializationResult);
    }

    void m118d();

    void m119e();
}
