package com.google.android.youtube.player.internal;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.support.v7.widget.ListPopupWindow;
import android.util.Log;
import com.google.android.youtube.player.YouTubeApiServiceUtil;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.internal.C0181c.C0281a;
import com.google.android.youtube.player.internal.C0187i.C0293a;
import com.google.android.youtube.player.internal.C0202t.C0200a;
import com.google.android.youtube.player.internal.C0202t.C0201b;
import java.util.ArrayList;

/* renamed from: com.google.android.youtube.player.internal.r */
public abstract class C0301r<T extends IInterface> implements C0202t {
    final Handler f103a;
    private final Context f104b;
    private T f105c;
    private ArrayList<C0200a> f106d;
    private final ArrayList<C0200a> f107e;
    private boolean f108f;
    private ArrayList<C0201b> f109g;
    private boolean f110h;
    private final ArrayList<C0198b<?>> f111i;
    private ServiceConnection f112j;
    private boolean f113k;

    /* renamed from: com.google.android.youtube.player.internal.r.1 */
    static /* synthetic */ class C01961 {
        static final /* synthetic */ int[] f41a;

        static {
            f41a = new int[YouTubeInitializationResult.values().length];
            try {
                f41a[YouTubeInitializationResult.SUCCESS.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
        }
    }

    /* renamed from: com.google.android.youtube.player.internal.r.a */
    final class C0197a extends Handler {
        final /* synthetic */ C0301r f42a;

        C0197a(C0301r c0301r) {
            this.f42a = c0301r;
        }

        public final void handleMessage(Message message) {
            if (message.what == 3) {
                this.f42a.m284a((YouTubeInitializationResult) message.obj);
            } else if (message.what == 4) {
                synchronized (this.f42a.f106d) {
                    if (this.f42a.f113k && this.f42a.m291f() && this.f42a.f106d.contains(message.obj)) {
                        ((C0200a) message.obj).m115a();
                    }
                }
            } else if (message.what == 2 && !this.f42a.m291f()) {
            } else {
                if (message.what == 2 || message.what == 1) {
                    ((C0198b) message.obj).m112a();
                }
            }
        }
    }

    /* renamed from: com.google.android.youtube.player.internal.r.b */
    protected abstract class C0198b<TListener> {
        final /* synthetic */ C0301r f43a;
        private TListener f44b;

        public C0198b(C0301r c0301r, TListener tListener) {
            this.f43a = c0301r;
            this.f44b = tListener;
            synchronized (c0301r.f111i) {
                c0301r.f111i.add(this);
            }
        }

        public final void m112a() {
            Object obj;
            synchronized (this) {
                obj = this.f44b;
            }
            m113a(obj);
        }

        protected abstract void m113a(TListener tListener);

        public final void m114b() {
            synchronized (this) {
                this.f44b = null;
            }
        }
    }

    /* renamed from: com.google.android.youtube.player.internal.r.e */
    final class C0199e implements ServiceConnection {
        final /* synthetic */ C0301r f45a;

        C0199e(C0301r c0301r) {
            this.f45a = c0301r;
        }

        public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            this.f45a.m287b(iBinder);
        }

        public final void onServiceDisconnected(ComponentName componentName) {
            this.f45a.f105c = null;
            this.f45a.m293h();
        }
    }

    /* renamed from: com.google.android.youtube.player.internal.r.c */
    protected final class C0300c extends C0198b<Boolean> {
        public final YouTubeInitializationResult f100b;
        public final IBinder f101c;
        final /* synthetic */ C0301r f102d;

        public C0300c(C0301r c0301r, String str, IBinder iBinder) {
            this.f102d = c0301r;
            super(c0301r, Boolean.valueOf(true));
            this.f100b = C0301r.m278b(str);
            this.f101c = iBinder;
        }

        protected final /* synthetic */ void m273a(Object obj) {
            if (((Boolean) obj) != null) {
                switch (C01961.f41a[this.f100b.ordinal()]) {
                    case ListPopupWindow.POSITION_PROMPT_BELOW /*1*/:
                        try {
                            if (this.f102d.m286b().equals(this.f101c.getInterfaceDescriptor())) {
                                this.f102d.f105c = this.f102d.m283a(this.f101c);
                                if (this.f102d.f105c != null) {
                                    this.f102d.m292g();
                                    return;
                                }
                            }
                        } catch (RemoteException e) {
                        }
                        this.f102d.m277a();
                        this.f102d.m284a(YouTubeInitializationResult.INTERNAL_ERROR);
                    default:
                        this.f102d.m284a(this.f100b);
                }
            }
        }
    }

    /* renamed from: com.google.android.youtube.player.internal.r.d */
    protected final class C0318d extends C0281a {
        final /* synthetic */ C0301r f127a;

        protected C0318d(C0301r c0301r) {
            this.f127a = c0301r;
        }

        public final void m336a(String str, IBinder iBinder) {
            this.f127a.f103a.sendMessage(this.f127a.f103a.obtainMessage(1, new C0300c(this.f127a, str, iBinder)));
        }
    }

    protected C0301r(Context context, C0200a c0200a, C0201b c0201b) {
        this.f107e = new ArrayList();
        this.f108f = false;
        this.f110h = false;
        this.f111i = new ArrayList();
        this.f113k = false;
        if (Looper.getMainLooper().getThread() != Thread.currentThread()) {
            throw new IllegalStateException("Clients must be created on the UI thread.");
        }
        this.f104b = (Context) ab.m34a((Object) context);
        this.f106d = new ArrayList();
        this.f106d.add(ab.m34a((Object) c0200a));
        this.f109g = new ArrayList();
        this.f109g.add(ab.m34a((Object) c0201b));
        this.f103a = new C0197a(this);
    }

    private void m277a() {
        if (this.f112j != null) {
            try {
                this.f104b.unbindService(this.f112j);
            } catch (Throwable e) {
                Log.w("YouTubeClient", "Unexpected error from unbindService()", e);
            }
        }
        this.f105c = null;
        this.f112j = null;
    }

    private static YouTubeInitializationResult m278b(String str) {
        try {
            return YouTubeInitializationResult.valueOf(str);
        } catch (IllegalArgumentException e) {
            return YouTubeInitializationResult.UNKNOWN_ERROR;
        } catch (NullPointerException e2) {
            return YouTubeInitializationResult.UNKNOWN_ERROR;
        }
    }

    protected abstract T m283a(IBinder iBinder);

    protected final void m284a(YouTubeInitializationResult youTubeInitializationResult) {
        this.f103a.removeMessages(4);
        synchronized (this.f109g) {
            this.f110h = true;
            ArrayList arrayList = this.f109g;
            int size = arrayList.size();
            int i = 0;
            while (i < size) {
                if (this.f113k) {
                    if (this.f109g.contains(arrayList.get(i))) {
                        ((C0201b) arrayList.get(i)).m117a(youTubeInitializationResult);
                    }
                    i++;
                } else {
                    return;
                }
            }
            this.f110h = false;
        }
    }

    protected abstract void m285a(C0187i c0187i, C0318d c0318d) throws RemoteException;

    protected abstract String m286b();

    protected final void m287b(IBinder iBinder) {
        try {
            m285a(C0293a.m259a(iBinder), new C0318d(this));
        } catch (RemoteException e) {
            Log.w("YouTubeClient", "service died");
        }
    }

    protected abstract String m288c();

    public void m289d() {
        m293h();
        this.f113k = false;
        synchronized (this.f111i) {
            int size = this.f111i.size();
            for (int i = 0; i < size; i++) {
                ((C0198b) this.f111i.get(i)).m114b();
            }
            this.f111i.clear();
        }
        m277a();
    }

    public final void m290e() {
        this.f113k = true;
        YouTubeInitializationResult isYouTubeApiServiceAvailable = YouTubeApiServiceUtil.isYouTubeApiServiceAvailable(this.f104b);
        if (isYouTubeApiServiceAvailable != YouTubeInitializationResult.SUCCESS) {
            this.f103a.sendMessage(this.f103a.obtainMessage(3, isYouTubeApiServiceAvailable));
            return;
        }
        Intent intent = new Intent(m288c()).setPackage(C0208z.m129a(this.f104b));
        if (this.f112j != null) {
            Log.e("YouTubeClient", "Calling connect() while still connected, missing disconnect().");
            m277a();
        }
        this.f112j = new C0199e(this);
        if (!this.f104b.bindService(intent, this.f112j, 129)) {
            this.f103a.sendMessage(this.f103a.obtainMessage(3, YouTubeInitializationResult.ERROR_CONNECTING_TO_SERVICE));
        }
    }

    public final boolean m291f() {
        return this.f105c != null;
    }

    protected final void m292g() {
        boolean z = true;
        synchronized (this.f106d) {
            ab.m37a(!this.f108f);
            this.f103a.removeMessages(4);
            this.f108f = true;
            if (this.f107e.size() != 0) {
                z = false;
            }
            ab.m37a(z);
            ArrayList arrayList = this.f106d;
            int size = arrayList.size();
            for (int i = 0; i < size && this.f113k && m291f(); i++) {
                if (!this.f107e.contains(arrayList.get(i))) {
                    ((C0200a) arrayList.get(i)).m115a();
                }
            }
            this.f107e.clear();
            this.f108f = false;
        }
    }

    protected final void m293h() {
        this.f103a.removeMessages(4);
        synchronized (this.f106d) {
            this.f108f = true;
            ArrayList arrayList = this.f106d;
            int size = arrayList.size();
            for (int i = 0; i < size && this.f113k; i++) {
                if (this.f106d.contains(arrayList.get(i))) {
                    ((C0200a) arrayList.get(i)).m116b();
                }
            }
            this.f108f = false;
        }
    }

    protected final void m294i() {
        if (!m291f()) {
            throw new IllegalStateException("Not connected. Call connect() and wait for onConnected() to be called.");
        }
    }

    protected final T m295j() {
        m294i();
        return this.f105c;
    }
}
