package com.google.android.youtube.player.internal;

import android.os.IBinder;

/* renamed from: com.google.android.youtube.player.internal.b */
public interface C0279b extends C0202t {
    IBinder m195a();

    C0189k m196a(C0188j c0188j);

    void m197a(boolean z);
}
