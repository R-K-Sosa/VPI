package com.google.android.youtube.player.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import android.support.v4.app.NotificationCompat.WearableExtender;
import android.support.v4.media.TransportMediator;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.widget.ListPopupWindow;

/* renamed from: com.google.android.youtube.player.internal.f */
public interface C0184f extends IInterface {

    /* renamed from: com.google.android.youtube.player.internal.f.a */
    public static abstract class C0287a extends Binder implements C0184f {

        /* renamed from: com.google.android.youtube.player.internal.f.a.a */
        private static class C0286a implements C0184f {
            private IBinder f93a;

            C0286a(IBinder iBinder) {
                this.f93a = iBinder;
            }

            public final void m244a() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IPlaybackEventListener");
                    this.f93a.transact(1, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public final void m245a(int i) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IPlaybackEventListener");
                    obtain.writeInt(i);
                    this.f93a.transact(5, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public final void m246a(boolean z) throws RemoteException {
                int i = 0;
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IPlaybackEventListener");
                    if (z) {
                        i = 1;
                    }
                    obtain.writeInt(i);
                    this.f93a.transact(4, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public final IBinder asBinder() {
                return this.f93a;
            }

            public final void m247b() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IPlaybackEventListener");
                    this.f93a.transact(2, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public final void m248c() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IPlaybackEventListener");
                    this.f93a.transact(3, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }
        }

        public C0287a() {
            attachInterface(this, "com.google.android.youtube.player.internal.IPlaybackEventListener");
        }

        public IBinder asBinder() {
            return this;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            switch (i) {
                case ListPopupWindow.POSITION_PROMPT_BELOW /*1*/:
                    parcel.enforceInterface("com.google.android.youtube.player.internal.IPlaybackEventListener");
                    m83a();
                    parcel2.writeNoException();
                    return true;
                case ListPopupWindow.INPUT_METHOD_NOT_NEEDED /*2*/:
                    parcel.enforceInterface("com.google.android.youtube.player.internal.IPlaybackEventListener");
                    m86b();
                    parcel2.writeNoException();
                    return true;
                case DrawerLayout.LOCK_MODE_UNDEFINED /*3*/:
                    parcel.enforceInterface("com.google.android.youtube.player.internal.IPlaybackEventListener");
                    m87c();
                    parcel2.writeNoException();
                    return true;
                case TransportMediator.FLAG_KEY_MEDIA_PLAY /*4*/:
                    parcel.enforceInterface("com.google.android.youtube.player.internal.IPlaybackEventListener");
                    m85a(parcel.readInt() != 0);
                    parcel2.writeNoException();
                    return true;
                case WearableExtender.SIZE_FULL_SCREEN /*5*/:
                    parcel.enforceInterface("com.google.android.youtube.player.internal.IPlaybackEventListener");
                    m84a(parcel.readInt());
                    parcel2.writeNoException();
                    return true;
                case 1598968902:
                    parcel2.writeString("com.google.android.youtube.player.internal.IPlaybackEventListener");
                    return true;
                default:
                    return super.onTransact(i, parcel, parcel2, i2);
            }
        }
    }

    void m83a() throws RemoteException;

    void m84a(int i) throws RemoteException;

    void m85a(boolean z) throws RemoteException;

    void m86b() throws RemoteException;

    void m87c() throws RemoteException;
}
