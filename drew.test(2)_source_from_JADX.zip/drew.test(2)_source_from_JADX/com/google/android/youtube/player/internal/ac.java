package com.google.android.youtube.player.internal;

import android.app.Activity;
import android.content.Context;
import com.google.android.youtube.player.YouTubeThumbnailView;
import com.google.android.youtube.player.internal.C0202t.C0200a;
import com.google.android.youtube.player.internal.C0202t.C0201b;
import com.google.android.youtube.player.internal.C0205w.C0204a;

public final class ac extends aa {
    public final C0278a m192a(C0279b c0279b, YouTubeThumbnailView youTubeThumbnailView) {
        return new C0317p(c0279b, youTubeThumbnailView);
    }

    public final C0279b m193a(Context context, String str, C0200a c0200a, C0201b c0201b) {
        return new C0315o(context, str, context.getPackageName(), C0208z.m136d(context), c0200a, c0201b);
    }

    public final C0182d m194a(Activity activity, C0279b c0279b, boolean z) throws C0204a {
        return C0205w.m122a(activity, c0279b.m195a(), z);
    }
}
