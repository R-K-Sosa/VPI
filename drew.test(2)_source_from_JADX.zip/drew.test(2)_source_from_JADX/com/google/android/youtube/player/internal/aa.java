package com.google.android.youtube.player.internal;

import android.app.Activity;
import android.content.Context;
import com.google.android.youtube.player.YouTubeThumbnailView;
import com.google.android.youtube.player.internal.C0202t.C0200a;
import com.google.android.youtube.player.internal.C0202t.C0201b;
import com.google.android.youtube.player.internal.C0205w.C0204a;

public abstract class aa {
    private static final aa f19a;

    static {
        f19a = m30b();
    }

    public static aa m29a() {
        return f19a;
    }

    private static aa m30b() {
        try {
            return (aa) Class.forName("com.google.android.youtube.api.locallylinked.LocallyLinkedFactory").asSubclass(aa.class).newInstance();
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        } catch (Throwable e2) {
            throw new IllegalStateException(e2);
        } catch (ClassNotFoundException e3) {
            return new ac();
        }
    }

    public abstract C0278a m31a(C0279b c0279b, YouTubeThumbnailView youTubeThumbnailView);

    public abstract C0279b m32a(Context context, String str, C0200a c0200a, C0201b c0201b);

    public abstract C0182d m33a(Activity activity, C0279b c0279b, boolean z) throws C0204a;
}
