package com.google.android.youtube.player.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.widget.ListPopupWindow;
import com.google.android.youtube.player.internal.C0188j.C0295a.C0294a;
import com.google.android.youtube.player.internal.C0189k.C0297a;

/* renamed from: com.google.android.youtube.player.internal.l */
public interface C0190l extends IInterface {

    /* renamed from: com.google.android.youtube.player.internal.l.a */
    public static abstract class C0299a extends Binder implements C0190l {

        /* renamed from: com.google.android.youtube.player.internal.l.a.a */
        private static class C0298a implements C0190l {
            private IBinder f99a;

            C0298a(IBinder iBinder) {
                this.f99a = iBinder;
            }

            public final IBinder m269a() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IYouTubeService");
                    this.f99a.transact(1, obtain, obtain2, 0);
                    obtain2.readException();
                    IBinder readStrongBinder = obtain2.readStrongBinder();
                    return readStrongBinder;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public final C0189k m270a(C0188j c0188j) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IYouTubeService");
                    obtain.writeStrongBinder(c0188j != null ? c0188j.asBinder() : null);
                    this.f99a.transact(2, obtain, obtain2, 0);
                    obtain2.readException();
                    C0189k a = C0297a.m268a(obtain2.readStrongBinder());
                    return a;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public final void m271a(boolean z) throws RemoteException {
                int i = 0;
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IYouTubeService");
                    if (z) {
                        i = 1;
                    }
                    obtain.writeInt(i);
                    this.f99a.transact(3, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public final IBinder asBinder() {
                return this.f99a;
            }
        }

        public static C0190l m272a(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.youtube.player.internal.IYouTubeService");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof C0190l)) ? new C0298a(iBinder) : (C0190l) queryLocalInterface;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            IBinder iBinder = null;
            switch (i) {
                case ListPopupWindow.POSITION_PROMPT_BELOW /*1*/:
                    parcel.enforceInterface("com.google.android.youtube.player.internal.IYouTubeService");
                    IBinder a = m106a();
                    parcel2.writeNoException();
                    parcel2.writeStrongBinder(a);
                    return true;
                case ListPopupWindow.INPUT_METHOD_NOT_NEEDED /*2*/:
                    C0188j c0188j;
                    parcel.enforceInterface("com.google.android.youtube.player.internal.IYouTubeService");
                    IBinder readStrongBinder = parcel.readStrongBinder();
                    if (readStrongBinder == null) {
                        c0188j = null;
                    } else {
                        IInterface queryLocalInterface = readStrongBinder.queryLocalInterface("com.google.android.youtube.player.internal.IThumbnailLoaderClient");
                        c0188j = (queryLocalInterface == null || !(queryLocalInterface instanceof C0188j)) ? new C0294a(readStrongBinder) : (C0188j) queryLocalInterface;
                    }
                    C0189k a2 = m107a(c0188j);
                    parcel2.writeNoException();
                    if (a2 != null) {
                        iBinder = a2.asBinder();
                    }
                    parcel2.writeStrongBinder(iBinder);
                    return true;
                case DrawerLayout.LOCK_MODE_UNDEFINED /*3*/:
                    parcel.enforceInterface("com.google.android.youtube.player.internal.IYouTubeService");
                    m108a(parcel.readInt() != 0);
                    parcel2.writeNoException();
                    return true;
                case 1598968902:
                    parcel2.writeString("com.google.android.youtube.player.internal.IYouTubeService");
                    return true;
                default:
                    return super.onTransact(i, parcel, parcel2, i2);
            }
        }
    }

    IBinder m106a() throws RemoteException;

    C0189k m107a(C0188j c0188j) throws RemoteException;

    void m108a(boolean z) throws RemoteException;
}
