package com.google.android.youtube.player.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import android.support.v7.widget.ListPopupWindow;

/* renamed from: com.google.android.youtube.player.internal.c */
public interface C0181c extends IInterface {

    /* renamed from: com.google.android.youtube.player.internal.c.a */
    public static abstract class C0281a extends Binder implements C0181c {

        /* renamed from: com.google.android.youtube.player.internal.c.a.a */
        private static class C0280a implements C0181c {
            private IBinder f90a;

            C0280a(IBinder iBinder) {
                this.f90a = iBinder;
            }

            public final void m198a(String str, IBinder iBinder) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IConnectionCallbacks");
                    obtain.writeString(str);
                    obtain.writeStrongBinder(iBinder);
                    this.f90a.transact(1, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public final IBinder asBinder() {
                return this.f90a;
            }
        }

        public C0281a() {
            attachInterface(this, "com.google.android.youtube.player.internal.IConnectionCallbacks");
        }

        public IBinder asBinder() {
            return this;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            switch (i) {
                case ListPopupWindow.POSITION_PROMPT_BELOW /*1*/:
                    parcel.enforceInterface("com.google.android.youtube.player.internal.IConnectionCallbacks");
                    m38a(parcel.readString(), parcel.readStrongBinder());
                    parcel2.writeNoException();
                    return true;
                case 1598968902:
                    parcel2.writeString("com.google.android.youtube.player.internal.IConnectionCallbacks");
                    return true;
                default:
                    return super.onTransact(i, parcel, parcel2, i2);
            }
        }
    }

    void m38a(String str, IBinder iBinder) throws RemoteException;
}
