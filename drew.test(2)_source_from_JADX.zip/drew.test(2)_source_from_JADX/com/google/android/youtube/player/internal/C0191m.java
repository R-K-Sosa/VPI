package com.google.android.youtube.player.internal;

import android.content.Context;
import android.content.res.Resources;
import java.util.Locale;
import java.util.Map;

/* renamed from: com.google.android.youtube.player.internal.m */
public final class C0191m {
    public final String f20a;
    public final String f21b;
    public final String f22c;
    public final String f23d;
    public final String f24e;
    public final String f25f;
    public final String f26g;
    public final String f27h;
    public final String f28i;
    public final String f29j;

    public C0191m(Context context) {
        Resources resources = context.getResources();
        Locale locale = (resources == null || resources.getConfiguration() == null || resources.getConfiguration().locale == null) ? Locale.getDefault() : resources.getConfiguration().locale;
        Map a = C0206x.m123a(locale);
        this.f20a = (String) a.get("error_initializing_player");
        this.f21b = (String) a.get("get_youtube_app_title");
        this.f22c = (String) a.get("get_youtube_app_text");
        this.f23d = (String) a.get("get_youtube_app_action");
        this.f24e = (String) a.get("enable_youtube_app_title");
        this.f25f = (String) a.get("enable_youtube_app_text");
        this.f26g = (String) a.get("enable_youtube_app_action");
        this.f27h = (String) a.get("update_youtube_app_title");
        this.f28i = (String) a.get("update_youtube_app_text");
        this.f29j = (String) a.get("update_youtube_app_action");
    }
}
