package com.google.android.youtube.player.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import android.support.v7.widget.ListPopupWindow;

/* renamed from: com.google.android.youtube.player.internal.e */
public interface C0183e extends IInterface {

    /* renamed from: com.google.android.youtube.player.internal.e.a */
    public static abstract class C0285a extends Binder implements C0183e {

        /* renamed from: com.google.android.youtube.player.internal.e.a.a */
        private static class C0284a implements C0183e {
            private IBinder f92a;

            C0284a(IBinder iBinder) {
                this.f92a = iBinder;
            }

            public final void m243a(boolean z) throws RemoteException {
                int i = 1;
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IOnFullscreenListener");
                    if (!z) {
                        i = 0;
                    }
                    obtain.writeInt(i);
                    this.f92a.transact(1, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public final IBinder asBinder() {
                return this.f92a;
            }
        }

        public C0285a() {
            attachInterface(this, "com.google.android.youtube.player.internal.IOnFullscreenListener");
        }

        public IBinder asBinder() {
            return this;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            switch (i) {
                case ListPopupWindow.POSITION_PROMPT_BELOW /*1*/:
                    parcel.enforceInterface("com.google.android.youtube.player.internal.IOnFullscreenListener");
                    m82a(parcel.readInt() != 0);
                    parcel2.writeNoException();
                    return true;
                case 1598968902:
                    parcel2.writeString("com.google.android.youtube.player.internal.IOnFullscreenListener");
                    return true;
                default:
                    return super.onTransact(i, parcel, parcel2, i2);
            }
        }
    }

    void m82a(boolean z) throws RemoteException;
}
