package com.google.android.youtube.player.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

/* renamed from: com.google.android.youtube.player.internal.u */
public interface C0203u extends IInterface {

    /* renamed from: com.google.android.youtube.player.internal.u.a */
    public static abstract class C0304a extends Binder implements C0203u {

        /* renamed from: com.google.android.youtube.player.internal.u.a.a */
        private static class C0303a implements C0203u {
            private IBinder f116a;

            C0303a(IBinder iBinder) {
                this.f116a = iBinder;
            }

            public final IBinder asBinder() {
                return this.f116a;
            }
        }

        public C0304a() {
            attachInterface(this, "com.google.android.youtube.player.internal.dynamic.IObjectWrapper");
        }

        public static C0203u m310a(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.youtube.player.internal.dynamic.IObjectWrapper");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof C0203u)) ? new C0303a(iBinder) : (C0203u) queryLocalInterface;
        }

        public IBinder asBinder() {
            return this;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            switch (i) {
                case 1598968902:
                    parcel2.writeString("com.google.android.youtube.player.internal.dynamic.IObjectWrapper");
                    return true;
                default:
                    return super.onTransact(i, parcel, parcel2, i2);
            }
        }
    }
}
