package android.support.v4;

/* renamed from: android.support.v4.R */
public final class C0010R {
}
