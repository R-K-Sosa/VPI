package android.support.v4.app;

import android.annotation.TargetApi;
import android.support.annotation.RequiresApi;

@TargetApi(23)
@RequiresApi(23)
class NotificationCompatApi23 {
    public static final String CATEGORY_REMINDER = "reminder";

    NotificationCompatApi23() {
    }
}
