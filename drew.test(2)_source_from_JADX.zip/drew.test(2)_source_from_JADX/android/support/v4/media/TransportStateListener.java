package android.support.v4.media;

@Deprecated
public class TransportStateListener {
    @Deprecated
    public void onPlayingChanged(TransportController controller) {
    }

    @Deprecated
    public void onTransportControlsChanged(TransportController controller) {
    }
}
