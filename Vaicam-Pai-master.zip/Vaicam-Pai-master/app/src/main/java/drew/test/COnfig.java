package drew.test;

public class COnfig {
    COnfig(){

    }
    public static final String API_KEY = "AIzaSyCXeSBgEPP-_JDAhyDdl0Nram9-uoYneQw";
}
