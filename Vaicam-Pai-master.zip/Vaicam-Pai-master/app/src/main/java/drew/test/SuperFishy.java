package drew.test;

/**
 * Created by Drew on 4/22/2017.
 */

public class SuperFishy {
    String fish;

    public SuperFishy(String fish) {
        this.fish = fish;
    }

    public SuperFishy() {

    }

    public String getFish() {

        return fish;
    }

    public void setFish(String fish) {
        this.fish = fish;
    }
}
