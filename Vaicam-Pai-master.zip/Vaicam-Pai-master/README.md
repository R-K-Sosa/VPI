json already is our api in array format

for element in json:  
  /t for "name" in element:  
   /t/t button.text = name;   
   /t for "value" in element:  
     /t/t button.text = value;  
  

